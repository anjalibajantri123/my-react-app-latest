import React from 'react'

export default function Home() {
  return (
    <div  style={{display: 'flex',  justifyContent:'center', alignItems:'center', height: '100vh'}}>
        <h3 style={{color: "#000", textAlign:"center", fontSize : "36px" }}>My React Website</h3>
    </div>
  )
}
